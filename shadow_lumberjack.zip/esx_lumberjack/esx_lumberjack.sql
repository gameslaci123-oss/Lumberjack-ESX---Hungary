-- Tárgyak hozzáadása az adatbázishoz

INSERT INTO `items` (`name`, `label`, `weight`, `rare`, `can_remove`) VALUES
    ('axe', 'Fejsze', 2, 0, 1),
    ('wood', 'Nyers fa', 1, 0, 1),
    ('processed_wood', 'Feldolgozott fa', 1, 0, 1)
ON DUPLICATE KEY UPDATE 
    `label` = VALUES(`label`),
    `weight` = VALUES(`weight`);
