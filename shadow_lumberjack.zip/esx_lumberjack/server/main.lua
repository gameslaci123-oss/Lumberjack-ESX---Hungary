ESX = exports["es_extended"]:getSharedObject()

-- Fejsze vásárlás callback
ESX.RegisterServerCallback('esx_lumberjack:buyAxe', function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)
    local axeCount = xPlayer.getInventoryItem('axe').count
    
    if axeCount > 0 then
        TriggerClientEvent('esx:showNotification', source, '~r~Már van fejszéd!')
        cb(false)
        return
    end
    
    if xPlayer.getMoney() >= Config.AxePrice then
        xPlayer.removeMoney(Config.AxePrice)
        xPlayer.addInventoryItem('axe', 1)
        cb(true)
    else
        cb(false)
    end
end)

-- Fejsze ellenőrzés callback
ESX.RegisterServerCallback('esx_lumberjack:hasAxe', function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)
    local axeCount = xPlayer.getInventoryItem('axe').count
    
    cb(axeCount > 0)
end)

-- Fa vágás jutalom
RegisterServerEvent('esx_lumberjack:chopTree')
AddEventHandler('esx_lumberjack:chopTree', function()
    local xPlayer = ESX.GetPlayerFromId(source)
    local axeCount = xPlayer.getInventoryItem('axe').count
    
    if axeCount > 0 then
        local amount = math.random(Config.WoodPerTreeMin, Config.WoodPerTreeMax)
        xPlayer.addInventoryItem('wood', amount)
        TriggerClientEvent('esx:showNotification', source, '~g~Sikeresen vágtál ' .. amount .. ' db fát!')
    else
        TriggerClientEvent('esx:showNotification', source, '~r~Nincs fejszéd!')
    end
end)

-- Feldolgozás ellenőrzés callback
ESX.RegisterServerCallback('esx_lumberjack:canProcess', function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)
    local woodCount = xPlayer.getInventoryItem('wood').count
    
    if woodCount > 0 then
        local processAmount = math.min(woodCount, Config.MaxProcessAmount)
        cb(true, processAmount)
    else
        cb(false, 0)
    end
end)

-- Fa feldolgozás
RegisterServerEvent('esx_lumberjack:processWood')
AddEventHandler('esx_lumberjack:processWood', function(amount)
    local xPlayer = ESX.GetPlayerFromId(source)
    local woodCount = xPlayer.getInventoryItem('wood').count
    
    if woodCount >= amount then
        xPlayer.removeInventoryItem('wood', amount)
        xPlayer.addInventoryItem('processed_wood', amount)
        
        TriggerClientEvent('esx:showNotification', source, '~g~Feldolgoztál ' .. amount .. ' db fát!')
    else
        TriggerClientEvent('esx:showNotification', source, '~r~Nincs elég nyers fád!')
    end
end)

-- Fa információ lekérés callback
ESX.RegisterServerCallback('esx_lumberjack:getWoodInfo', function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)
    local processedWood = xPlayer.getInventoryItem('processed_wood').count
    local rawWood = xPlayer.getInventoryItem('wood').count
    
    cb(processedWood, rawWood)
end)

-- Fa eladás
RegisterServerEvent('esx_lumberjack:sellWood')
AddEventHandler('esx_lumberjack:sellWood', function(woodType)
    local xPlayer = ESX.GetPlayerFromId(source)
    local totalMoney = 0
    
    if woodType == 'processed' or woodType == 'all' then
        local processedWood = xPlayer.getInventoryItem('processed_wood').count
        if processedWood > 0 then
            local processedPrice = math.random(Config.ProcessedWoodPriceMin, Config.ProcessedWoodPriceMax)
            local processedTotal = processedWood * processedPrice
            totalMoney = totalMoney + processedTotal
            xPlayer.removeInventoryItem('processed_wood', processedWood)
            TriggerClientEvent('esx:showNotification', source, '~g~Eladtál ' .. processedWood .. ' db feldolgozott fát $' .. processedTotal .. '-ért!')
        end
    end
    
    if woodType == 'raw' or woodType == 'all' then
        local rawWood = xPlayer.getInventoryItem('wood').count
        if rawWood > 0 then
            local rawPrice = math.random(Config.RawWoodPriceMin, Config.RawWoodPriceMax)
            local rawTotal = rawWood * rawPrice
            totalMoney = totalMoney + rawTotal
            xPlayer.removeInventoryItem('wood', rawWood)
            TriggerClientEvent('esx:showNotification', source, '~g~Eladtál ' .. rawWood .. ' db nyers fát $' .. rawTotal .. '-ért!')
        end
    end
    
    if totalMoney > 0 then
        xPlayer.addMoney(totalMoney)
        TriggerClientEvent('esx:showNotification', source, '~g~Összesen kaptál: $' .. totalMoney)
    else
        TriggerClientEvent('esx:showNotification', source, '~r~Nincs eladható fád!')
    end
end)

print('^2[ESX Lumberjack]^7 Script successfully loaded!')
