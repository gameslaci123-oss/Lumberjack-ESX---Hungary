Config = {}

-- Marker beállítások
Config.DrawDistance = 100.0
Config.MarkerSize = {x = 1.5, y = 1.5, z = 0.5}
Config.MarkerColor = {r = 46, g = 204, b = 113} -- Zöld
Config.MarkerType = 1
Config.InteractionDistance = 2.5

-- Időzítések (milliszekundumban)
Config.ProcessTime = 8000 -- 8 másodperc - fa feldolgozás ideje
Config.ChopTime = 12000 -- 12 másodperc - favágás ideje
Config.AxeDurability = 100 -- Fejsze használat előtt elromlik

-- Jutalmak
Config.WoodPerTreeMin = 2 -- Minimum fa mennyiség vágásonként
Config.WoodPerTreeMax = 5 -- Maximum fa mennyiség vágásonként
Config.MaxProcessAmount = 10 -- Maximum egyszerre feldolgozható fa

-- Árak
Config.ProcessedWoodPriceMin = 45 -- Minimum ár feldolgozott fáért
Config.ProcessedWoodPriceMax = 75 -- Maximum ár feldolgozott fáért
Config.RawWoodPriceMin = 15 -- Minimum ár nyers fáért
Config.RawWoodPriceMax = 25 -- Maximum ár nyers fáért
Config.AxePrice = 250 -- Fejsze ára

-- NPC Boss helyszín (munkakezdés)
Config.BossNPC = {
    coords = vector3(-585.3517, 5322.8789, 70.2145),
    heading = 250.0,
    model = 's_m_y_construct_01', -- Építőmunkás model
    scenario = 'WORLD_HUMAN_CLIPBOARD'
}

-- Fák helyszínei (Paleto Forest - FÖLDÖN!)
Config.TreeLocations = {
    -- Első csoport
    vector3(-632.5643, 5275.7290, 68.7173),
    vector3(-644.9885, 5270.0801, 73.4155),
    vector3(-663.1490, 5278.1133, 74.0525),
    vector3(-659.2464, 5292.6631, 70.3104),
    vector3(-656.1643, 5296.3970, 68.9694),
    -- Második csoport
    vector3(-663.5635, 5165.0059, 109.8320),
    vector3(-667.6301, 5171.6226, 108.4536),
    vector3(-635.8406, 5171.1777, 103.3961),
    vector3(-622.1926, 5163.1323, 104.8254),
    vector3(-615.1285, 5158.3394, 106.0068),
    -- Harmadik csoport
    vector3(-625.4261, 5144.7290, 112.2176),
    vector3(-619.0394, 5142.9146, 111.8915),
    vector3(-620.3932, 5137.8501, 113.7584),
    vector3(-610.1008, 5103.5425, 125.6094)
}

-- Feldolgozó helyszín
Config.ProcessLocation = {
    coords = vector3(-508.0514, 5269.7793, 80.6101),
    heading = 90.0
}

-- Eladó NPC helyszín
Config.SellerNPC = {
    coords = vector3(-538.5796, 5255.6919, 74.9363),
    heading = 160.0,
    model = 's_m_m_trucker_01',
    scenario = 'WORLD_HUMAN_CLIPBOARD'
}

Config.VehicleNPC = {
    model = 's_m_m_trucker_01', -- NPC modell
    coords = vector3(-579.7670, 5304.8916, 70.2492), -- NPC helye
    heading = 90.0, -- NPC iránya
    scenario = 'WORLD_HUMAN_STAND_IMPATIENT' -- NPC animáció
}

Config.VehicleSpawn = {
    coords = vector3(-587.6649, 5303.7100, 69.7920), -- jármű spawn hely
    heading = 90.0 -- jármű iránya
}

-- Blip beállítások
Config.Blips = {
    Start = {
        sprite = 85,
        color = 2,
        scale = 0.8,
        label = "Favágó munkahely"
    },
    Process = {
        sprite = 478,
        color = 5,
        scale = 0.8,
        label = "Fa feldolgozás"
    },
    Sell = {
        sprite = 500,
        color = 3,
        scale = 0.8,
        label = "Fa eladás"
    }
}
