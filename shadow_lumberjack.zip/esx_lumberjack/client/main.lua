ESX = exports["es_extended"]:getSharedObject()

local PlayerData = {}
local isWorking = false
local hasAxe = false
local bossNPC = nil
local sellerNPC = nil

-- ======================
-- PLAYER DATA
-- ======================
RegisterNetEvent('esx:playerLoaded', function(xPlayer)
    PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob', function(job)
    PlayerData.job = job
end)

-- ======================
-- NPC CREATE
-- ======================
CreateThread(function()
    RequestModel(Config.BossNPC.model)
    while not HasModelLoaded(Config.BossNPC.model) do Wait(100) end

    bossNPC = CreatePed(4, Config.BossNPC.model,
        Config.BossNPC.coords.x, Config.BossNPC.coords.y, Config.BossNPC.coords.z - 1.0,
        Config.BossNPC.heading, false, true)

    SetEntityInvincible(bossNPC, true)
    FreezeEntityPosition(bossNPC, true)
    SetBlockingOfNonTemporaryEvents(bossNPC, true)
    TaskStartScenarioInPlace(bossNPC, Config.BossNPC.scenario, 0, true)

    RequestModel(Config.SellerNPC.model)
    while not HasModelLoaded(Config.SellerNPC.model) do Wait(100) end

    sellerNPC = CreatePed(4, Config.SellerNPC.model,
        Config.SellerNPC.coords.x, Config.SellerNPC.coords.y, Config.SellerNPC.coords.z - 1.0,
        Config.SellerNPC.heading, false, true)

    SetEntityInvincible(sellerNPC, true)
    FreezeEntityPosition(sellerNPC, true)
    SetBlockingOfNonTemporaryEvents(sellerNPC, true)
    TaskStartScenarioInPlace(sellerNPC, Config.SellerNPC.scenario, 0, true)
end)

-- ======================
-- BLIPS
-- ======================
CreateThread(function()
    local blip = AddBlipForCoord(Config.BossNPC.coords)
    SetBlipSprite(blip, 85)
    SetBlipScale(blip, 0.8)
    SetBlipColour(blip, 2)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Favágó Boss")
    EndTextCommandSetBlipName(blip)

    local blip2 = AddBlipForCoord(Config.ProcessLocation.coords)
    SetBlipSprite(blip2, 478)
    SetBlipScale(blip2, 0.7)
    SetBlipColour(blip2, 5)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Fa feldolgozás")
    EndTextCommandSetBlipName(blip2)

    local blip3 = AddBlipForCoord(Config.SellerNPC.coords)
    SetBlipSprite(blip3, 500)
    SetBlipScale(blip3, 0.8)
    SetBlipColour(blip3, 3)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Fa vásárló")
    EndTextCommandSetBlipName(blip3)
end)

-- ======================
-- BOSS MENU
-- ======================
function OpenBossMenu()
    ESX.UI.Menu.CloseAll()
    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'boss_menu', {
        title = 'Favágó Boss',
        align = 'top-left',
        elements = {
            {label = '🪓 Fejsze vásárlás (Ft'..Config.AxePrice..')', value = 'axe'},
            {label = '❌ Kilépés', value = 'exit'}
        }
    }, function(data, menu)
        if data.current.value == 'axe' then
            ESX.TriggerServerCallback('esx_lumberjack:buyAxe', function(success)
                if success then
                    hasAxe = true
                    ESX.ShowNotification('~g~Fejsze megvéve')
                else
                    ESX.ShowNotification('~r~Nincs elég pénzed')
                end
            end)
        else
            menu.close()
        end
    end, function(data, menu)
        menu.close()
    end)
end

-- ======================
-- FAVÁGÁS
-- ======================
function StartChopping(treeCoords)
    if isWorking then return end

    ESX.TriggerServerCallback('esx_lumberjack:hasAxe', function(has)
        if not has then
            ESX.ShowNotification('~r~Nincs fejszéd!')
            return
        end

        isWorking = true
        local ped = PlayerPedId()

        RequestAnimDict("melee@large_wpn@streamed_core")
        while not HasAnimDictLoaded("melee@large_wpn@streamed_core") do Wait(50) end

        RequestModel("prop_tool_fireaxe")
        while not HasModelLoaded("prop_tool_fireaxe") do Wait(50) end

        local axe = CreateObject("prop_tool_fireaxe", 0,0,0, true,true,true)
        AttachEntityToEntity(axe, ped, GetPedBoneIndex(ped, 57005),
          -0.05, -0.0, 0.05,  -- X,Y,Z offset
         -30.0, -30.0, 60.0, -- X,Y,Z rotáció
         true, true, false, true)

        FreezeEntityPosition(ped, true)
        ESX.ShowNotification('~g~Favágás folyamatban...')

        local endTime = GetGameTimer() + Config.ChopTime
        while GetGameTimer() < endTime do
            TaskPlayAnim(ped, "melee@large_wpn@streamed_core",
                "ground_attack_on_spot", 3.0,3.0,-1,1,0,false,false,false)
            Wait(2500)
        end

        ClearPedTasksImmediately(ped)
        FreezeEntityPosition(ped, false)
        DeleteObject(axe)

        isWorking = false
        TriggerServerEvent('esx_lumberjack:chopTree')
    end)
end

-- ======================
-- PROCESS
-- ======================
function ProcessWood()
    if isWorking then return end

    ESX.TriggerServerCallback('esx_lumberjack:canProcess', function(can, amount)
        if not can then
            ESX.ShowNotification('~r~Nincs nyers fád!')
            return
        end

        isWorking = true
        local ped = PlayerPedId()

        RequestAnimDict("anim@amb@clubhouse@tutorial@bkr_tut_ig3@")
        while not HasAnimDictLoaded("anim@amb@clubhouse@tutorial@bkr_tut_ig3@") do Wait(50) end

        TaskPlayAnim(ped, "anim@amb@clubhouse@tutorial@bkr_tut_ig3@",
            "machinic_loop_mechandplayer", 8.0,-8.0,-1,1,0,false,false,false)

        Wait(Config.ProcessTime)
        ClearPedTasksImmediately(ped)

        isWorking = false
        TriggerServerEvent('esx_lumberjack:processWood', amount)
    end)
end

-- ======================
-- SELL MENU
-- ======================
function SellWood()
    ESX.UI.Menu.CloseAll()
    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'sell_menu', {
        title = 'Fa eladás',
        align = 'top-left',
        elements = {
            {label = '💰 Mind eladása', value = 'all'},
            {label = '❌ Kilépés', value = 'exit'}
        }
    }, function(data, menu)
        if data.current.value == 'all' then
            TriggerServerEvent('esx_lumberjack:sellWood', 'all')
            menu.close()
        else
            menu.close()
        end
    end, function(data, menu)
        menu.close()
    end)
end

-- ======================
-- MARKERS + E
-- ======================
CreateThread(function()
    while true do
        local sleep = 1000
        local ped = PlayerPedId()
        local coords = GetEntityCoords(ped)

        -- FÁK
        for _, tree in pairs(Config.TreeLocations) do
            if #(coords - tree) < 30.0 then
                sleep = 0
                DrawMarker(1, tree.x, tree.y, tree.z - 1.0,
                    0,0,0, 0,0,0,
                    1.2,1.2,1.2, 0,255,0,120, false,true)

                if #(coords - tree) < Config.InteractionDistance then
                    ESX.ShowHelpNotification('~INPUT_CONTEXT~ Favágás')
                    if IsControlJustReleased(0,38) then
                        StartChopping(tree)
                    end
                end
            end
        end

        -- BOSS
        if #(coords - Config.BossNPC.coords) < Config.InteractionDistance then
            sleep = 0
            DrawMarker(27, Config.BossNPC.coords.x, Config.BossNPC.coords.y, Config.BossNPC.coords.z + 1.0,
                0,0,0,0,0,0,1.0,1.0,1.0,255,255,0,120,false,true)

            ESX.ShowHelpNotification('~INPUT_CONTEXT~ Boss menü')
            if IsControlJustReleased(0,38) then OpenBossMenu() end
        end

        -- PROCESS
        if #(coords - Config.ProcessLocation.coords) < Config.InteractionDistance then
            sleep = 0
            DrawMarker(1, Config.ProcessLocation.coords.x, Config.ProcessLocation.coords.y,
                Config.ProcessLocation.coords.z - 1.0,
                0,0,0,0,0,0,1.5,1.5,0.5,255,165,0,120,false,true)

            ESX.ShowHelpNotification('~INPUT_CONTEXT~ Feldolgozás')
            if IsControlJustReleased(0,38) then ProcessWood() end
        end

        -- SELLER
        if #(coords - Config.SellerNPC.coords) < Config.InteractionDistance then
            sleep = 0
            DrawMarker(27, Config.SellerNPC.coords.x, Config.SellerNPC.coords.y,
                Config.SellerNPC.coords.z + 1.0,
                0,0,0,0,0,0,1.0,1.0,1.0,0,255,0,120,false,true)

            ESX.ShowHelpNotification('~INPUT_CONTEXT~ Eladás')
            if IsControlJustReleased(0,38) then SellWood() end
        end

        Wait(sleep)
    end
end)

-- ======================
-- VEHICLE NPC CREATE
-- ======================
local vehicleNPC = nil

CreateThread(function()
    RequestModel(Config.VehicleNPC.model)
    while not HasModelLoaded(Config.VehicleNPC.model) do Wait(100) end

    vehicleNPC = CreatePed(4, Config.VehicleNPC.model,
        Config.VehicleNPC.coords.x, Config.VehicleNPC.coords.y, Config.VehicleNPC.coords.z - 1.0,
        Config.VehicleNPC.heading, false, true)

    SetEntityInvincible(vehicleNPC, true)
    FreezeEntityPosition(vehicleNPC, true)
    SetBlockingOfNonTemporaryEvents(vehicleNPC, true)
    TaskStartScenarioInPlace(vehicleNPC, Config.VehicleNPC.scenario, 0, true)
end)

-- ======================
-- VEHICLE MENU (VISSZAADÁS)
-- ======================
function OpenVehicleMenu()
    ESX.UI.Menu.CloseAll()
    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'vehicle_menu', {
        title = 'Favágó jármű',
        align = 'top-left',
        elements = {
            {label = '🚛 Favágó teherautó kivétel', value = 'lumber_truck'},
            {label = '↩️ Jármű visszaadás', value = 'return_vehicle'},
            {label = '❌ Kilépés', value = 'exit'}
        }
    }, function(data, menu)
        local playerPed = PlayerPedId()

        if data.current.value == 'lumber_truck' then
            local spawnPos = Config.VehicleSpawn.coords
            local spawnHeading = Config.VehicleSpawn.heading
            ESX.Game.SpawnVehicle('kalahari', spawnPos, spawnHeading, function(vehicle)
                TaskWarpPedIntoVehicle(playerPed, vehicle, -1)
                ESX.ShowNotification('~g~Favágó jármű megjelent')
            end)
            menu.close()

        elseif data.current.value == 'return_vehicle' then
            local veh = GetVehiclePedIsIn(playerPed, false)
            if veh and veh ~= 0 then
                DeleteVehicle(veh)
                ESX.ShowNotification('~g~Favágó jármű visszaadva')
            else
                ESX.ShowNotification('~r~Nincs járműved visszaadni')
            end
            menu.close()

        else
            menu.close()
        end
    end, function(data, menu)
        menu.close()
    end)
end

-- ======================
-- VEHICLE MARKER
-- ======================
CreateThread(function()
    while true do
        local sleep = 1000
        local ped = PlayerPedId()
        local coords = GetEntityCoords(ped)

        if #(coords - Config.VehicleNPC.coords) < Config.InteractionDistance then
            sleep = 0
            DrawMarker(27, Config.VehicleNPC.coords.x, Config.VehicleNPC.coords.y, Config.VehicleNPC.coords.z + 1.0,
                0,0,0,0,0,0,1.0,1.0,1.0,0,0,255,120,false,true)

            ESX.ShowHelpNotification('~INPUT_CONTEXT~ Jármű kivétel')
            if IsControlJustReleased(0,38) then
                OpenVehicleMenu()
            end
        end

        Wait(sleep)
    end
end)

-- ======================
-- CLEANUP VEHICLE NPC
-- ======================
AddEventHandler('onResourceStop', function(res)
    if res == GetCurrentResourceName() then
        if DoesEntityExist(vehicleNPC) then DeleteEntity(vehicleNPC) end
    end
end)

-- ======================
-- CLEANUP
-- ======================
AddEventHandler('onResourceStop', function(res)
    if res == GetCurrentResourceName() then
        if DoesEntityExist(bossNPC) then DeleteEntity(bossNPC) end
        if DoesEntityExist(sellerNPC) then DeleteEntity(sellerNPC) end
    end
end)
