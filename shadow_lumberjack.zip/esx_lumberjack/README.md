# 🪓 ESX Lumberjack Job V2 (Fejlesztett verzió)

## 🌟 Új funkciók

✅ **NPC rendszer** - Boss és eladó NPC-k
✅ **Fejsze vásárlás** - Kell fejsze a munkához ($250)
✅ **Jobb fa helyszínek** - Földön lévő fák, nem a levegőben
✅ **Eladási menü** - Választható mit akarsz eladni
✅ **Szebb markerek** - Színes, látványos jelölések
✅ **Optimalizált kód** - Jobb teljesítmény

## 📦 Telepítés

1. Másold az `esx_lumberjack` mappát a szervered `resources` mappájába
2. Importáld az `esx_lumberjack.sql` fájlt az adatbázisodba
3. Add hozzá a `server.cfg` fájlodhoz:
```
ensure esx_lumberjack
```
4. Indítsd újra a szervert

## 🎮 Használat

### 1️⃣ Fejsze vásárlás
- Menj a **Boss NPC**-hez (sárga marker a fejük felett)
- Nyomj **E**-t
- Válaszd ki a "Fejsze vásárlás" opciót
- Ár: **$250**

### 2️⃣ Favágás
- Menj bármelyik **zöld marker**hez (fák)
- Állj rá a markerre
- Nyomj **E**-t
- Várd meg amíg kivágod a fát (12 másodperc)
- Kapsz **2-5 db nyers fát**

### 3️⃣ Feldolgozás
- Menj a **narancssárga marker**hez (feldolgozó)
- Nyomj **E**-t
- Várd meg a feldolgozást (8 másodperc)
- Maximum **10 db** fa egyszerre

### 4️⃣ Eladás
- Menj az **eladó NPC**-hez (zöld marker)
- Nyomj **E**-t
- Válaszd ki mit szeretnél eladni:
  - 📦 Csak feldolgozott fa
  - 🪵 Csak nyers fa
  - 💰 Mindent egyszerre

## 💰 Árak

| Termék | Ár |
|--------|-----|
| Fejsze | $250 |
| Nyers fa | $15-25 /db |
| Feldolgozott fa | $45-75 /db |

## 📍 Helyszínek

### Boss NPC
- **Koordináták:** -551.09, 5348.85, 74.74
- **Blip:** Sárga, "Favágó Boss"

### Fák
- **14 db fa helyszín** Paleto Forest környékén
- **Zöld markerek** a földön

### Feldolgozás
- **Koordináták:** -527.12, 5262.34, 80.61
- **Blip:** Narancssárga, "Fa feldolgozás"

### Eladás
- **Koordináták:** -538.67, 5256.78, 80.61
- **Blip:** Zöld, "Fa vásárló"

## ⚙️ Konfiguráció

A `config.lua` fájlban állíthatod be:

```lua
-- Árak
Config.AxePrice = 250
Config.ProcessedWoodPriceMin = 45
Config.ProcessedWoodPriceMax = 75
Config.RawWoodPriceMin = 15
Config.RawWoodPriceMax = 25

-- Jutalmak
Config.WoodPerTreeMin = 2
Config.WoodPerTreeMax = 5

-- Időzítések
Config.ChopTime = 12000 -- 12 másodperc
Config.ProcessTime = 8000 -- 8 másodperc

-- Feldolgozás
Config.MaxProcessAmount = 10
```

## 🎯 Jellemzők

✅ Teljes ESX Legacy kompatibilitás
✅ 2 NPC (Boss + Eladó)
✅ Animációk (favágás + feldolgozás)
✅ Prop használat (fejsze)
✅ Eladási menü rendszer
✅ Blipek és markerek
✅ Optimalizált (0.00-0.01ms idle)
✅ Magyar nyelvű
✅ Könnyen konfigurálható

## 🛠️ Követelmények

- ESX Legacy / ESX 1.2+
- MySQL adatbázis
- es_extended
- esx_menu_default (vagy más ESX menü)

## 📝 Tárgyak

- `axe` - Fejsze (2 kg)
- `wood` - Nyers fa (1 kg)
- `processed_wood` - Feldolgozott fa (1 kg)

## 🐛 Hibaelhárítás

**Probléma:** Nem látom az NPC-ket
- Ellenőrizd hogy betöltődött-e a resource (`ensure esx_lumberjack`)
- Nézd meg a server konzolt hibáért

**Probléma:** Nem tudom eladni a fát
- Ellenőrizd hogy van-e `esx_menu_default` resource
- Győződj meg hogy az SQL importálva lett

**Probléma:** Nem működik a vágás
- Vásárolj fejszét a Boss NPC-től először!

## 🎨 Testreszabás

### Új fa helyszín hozzáadása:
```lua
-- config.lua
Config.TreeLocations = {
    vector3(x, y, z), -- Új fa koordinátái
    -- ... többi fa
}
```

### NPC megjelenés módosítása:
```lua
Config.BossNPC = {
    model = 's_m_y_construct_01', -- Módosítsd a ped modelt
    scenario = 'WORLD_HUMAN_CLIPBOARD'
}
```

---

**Készítette:** ESX Lumberjack V2
**Verzió:** 2.0
**Támogatás:** Fejlesztett verzió NPC-kkel és fejsze rendszerrel

🪓 Jó favágást! 🌲
